package com.teamabhpk.mrearn;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.ads.mediation.unity.*;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.unity3d.ads.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.jetbrains.kotlin.*;
import org.json.*;
import com.google.firebase.auth.UserProfileChangeRequest;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_GOOGLE = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	GoogleSignInOptions options;
	FirebaseUser users;
	private HashMap<String, Object> user = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> userdata = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear4;
	private ImageView imageview6;
	private TextView textview4;
	private ProgressBar progressbar1;
	private SignInButton button4;
	private TextView textview5;
	private EditText edittext1;
	private EditText edittext2;
	private TextView textview6;
	private Button button5;
	
	private GoogleSignInClient google;
	private FirebaseAuth fb_auth;
	private OnCompleteListener<AuthResult> _fb_auth_create_user_listener;
	private OnCompleteListener<AuthResult> _fb_auth_sign_in_listener;
	private OnCompleteListener<Void> _fb_auth_reset_password_listener;
	private OnCompleteListener<Void> fb_auth_updateEmailListener;
	private OnCompleteListener<Void> fb_auth_updatePasswordListener;
	private OnCompleteListener<Void> fb_auth_emailVerificationSentListener;
	private OnCompleteListener<Void> fb_auth_deleteUserListener;
	private OnCompleteListener<Void> fb_auth_updateProfileListener;
	private OnCompleteListener<AuthResult> fb_auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fb_auth_googleSignInListener;
	
	private Intent i = new Intent();
	private com.google.android.material.bottomsheet.BottomSheetDialog bottomsheet;
	private SharedPreferences shared;
	private AlertDialog.Builder how;
	private Intent privicypolicy = new Intent();
	private DatabaseReference fb_db = _firebase.getReference("users");
	private ChildEventListener _fb_db_child_listener;
	private Calendar c = Calendar.getInstance();
	private SharedPreferences use;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear4 = findViewById(R.id.linear4);
		imageview6 = findViewById(R.id.imageview6);
		textview4 = findViewById(R.id.textview4);
		progressbar1 = findViewById(R.id.progressbar1);
		button4 = findViewById(R.id.button4);
		textview5 = findViewById(R.id.textview5);
		edittext1 = findViewById(R.id.edittext1);
		edittext2 = findViewById(R.id.edittext2);
		textview6 = findViewById(R.id.textview6);
		button5 = findViewById(R.id.button5);
		fb_auth = FirebaseAuth.getInstance();
		shared = getSharedPreferences("app", Activity.MODE_PRIVATE);
		how = new AlertDialog.Builder(this);
		use = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				how.setTitle("How to login ?");
				how.setMessage("Click button below to select Google account  and Login. \nor\nEnter email and password and click login button.\nIt will automatically create account.\nYou must verify email first time. Verification mail will sent to you.\nAfter verification, enter email and password again to login.\nThen app will move automatically to Home page after login.");
				how.setPositiveButton("close", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				how.create().show();
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent signInIntent = google.getSignInIntent();
				
				startActivityForResult(signInIntent, REQ_CD_GOOGLE);
				progressbar1.setVisibility(View.VISIBLE);
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				fb_auth.sendPasswordResetEmail(edittext1.getText().toString()).addOnCompleteListener(_fb_auth_reset_password_listener);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					((EditText)edittext1).setError("Enter email");
				}
				else {
					if (edittext2.getText().toString().equals("")) {
						((EditText)edittext2).setError("Enter passcode");
					}
					else {
						progressbar1.setVisibility(View.VISIBLE);
						fb_auth.createUserWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(MainActivity.this, _fb_auth_create_user_listener);
					}
				}
			}
		});
		
		_fb_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fb_db.addChildEventListener(_fb_db_child_listener);
		
		fb_auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				progressbar1.setVisibility(View.INVISIBLE);
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "Verification email sent");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		fb_auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				progressbar1.setVisibility(View.INVISIBLE);
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "update profile successful ");
					i.setClass(getApplicationContext(), HomeActivity.class);
					startActivity(i);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		fb_auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				progressbar1.setVisibility(View.INVISIBLE);
				if (_success) {
					fb_auth.signInWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(MainActivity.this, _fb_auth_sign_in_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "create account success");
					use.edit().putString("uc", new SimpleDateFormat("yyyy:MM:dd:hh:mm:ss:aa").format(c.getTime())).commit();
				}
				else {
					if (_errorMessage.contains("email address is already in use")) {
						fb_auth.signInWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(MainActivity.this, _fb_auth_sign_in_listener);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
					}
				}
			}
		};
		
		_fb_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				progressbar1.setVisibility(View.INVISIBLE);
				if (_success) {
					if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()) {
						progressbar1.setVisibility(View.VISIBLE);
						FirebaseAuth.getInstance().getCurrentUser().updateProfile(new UserProfileChangeRequest.Builder().setDisplayName(edittext1.getText().toString()).setPhotoUri(Uri.parse("https://firebasestorage.googleapis.com/v0/b/mrearn-46b1c.appspot.com/o/profiles%2Fapp_icon.png?alt=media&token=5561843e-6932-487e-bbc7-40194c7aab85")).build()).addOnCompleteListener(fb_auth_updateProfileListener);
						SketchwareUtil.showMessage(getApplicationContext(), "Please profile picture and name ");
					}
					else {
						progressbar1.setVisibility(View.VISIBLE);
						FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(fb_auth_emailVerificationSentListener);
						SketchwareUtil.showMessage(getApplicationContext(), "Please verify email first !!!\nEmail mail is sending");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_fb_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		progressbar1.setVisibility(View.INVISIBLE);
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)1, 0xFF4CAF50, Color.TRANSPARENT));
		edittext2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)1, 0xFF4CAF50, Color.TRANSPARENT));
		button5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)3, 0xFF4CAF50, Color.TRANSPARENT));
		GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken("316998815762-s03t1tori4iq0fkmr8lqlek8vubosq7q.apps.googleusercontent.com").requestEmail().build();
		google = GoogleSignIn.getClient(this, options);
		fb_auth = FirebaseAuth.getInstance();
		if (shared.contains("agreed") && (FirebaseAuth.getInstance().getCurrentUser() != null)) {
			i.setClass(getApplicationContext(), HomeActivity.class);
			startActivity(i);
			finish();
		}
		if (!shared.contains("agreed")) {
			_bottomsheet_privicy();
			bottomsheet.setCancelable(false);
			bottomsheet.show();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_GOOGLE:
			if (_resultCode == Activity.RESULT_OK) {
				Task<GoogleSignInAccount> _task = GoogleSignIn.getSignedInAccountFromIntent(_data);
				
				try {
					                // Google Sign In was successful, authenticate with Firebase
					                GoogleSignInAccount account = _task.getResult(ApiException.class);
					                
					                firebaseAuthWithGoogle(account.getIdToken());
					            } catch (ApiException e) {
					                //On Fiailure
					                final String ErrorOnResultSign = e.getMessage();
					                SketchwareUtil.showMessage(getApplicationContext(), ErrorOnResultSign);
					            }
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "Google Account pock abborted !");
				progressbar1.setVisibility(View.INVISIBLE);
			}
			break;
			default:
			break;
		}
	}
	
	public void _signInWithGoogle() {
	}
	private void firebaseAuthWithGoogle(String idToken) {
		AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
		fb_auth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
			
			@Override
			public void onComplete(@NonNull Task<AuthResult> task) {
				if (task.isSuccessful()) {
					progressbar1.setVisibility(View.INVISIBLE);
					users = fb_auth.getCurrentUser();
					progressbar1.setVisibility(View.VISIBLE);
					fb_db.addListenerForSingleValueEvent(new ValueEventListener() {
						@Override
						public void onDataChange(DataSnapshot _dataSnapshot) {
							userdata = new ArrayList<>();
							try {
								GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
								for (DataSnapshot _data : _dataSnapshot.getChildren()) {
									HashMap<String, Object> _map = _data.getValue(_ind);
									userdata.add(_map);
								}
							}
							catch (Exception _e) {
								_e.printStackTrace();
							}
							progressbar1.setVisibility(View.INVISIBLE);
							user = new HashMap<>();
							if (use.contains("uc")) {
								user.put("user,created,at,", use.getString("uc", ""));
								use.edit().remove("user,created,at,").commit();
							}
							else {
								user.put("user,created,at,", "unavailible");
							}
							for(int _repeat74 = 0; _repeat74 < (int)(userdata.size()); _repeat74++) {
								if (userdata.get((int)_repeat74).containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
									if (userdata.get((int)_repeat74).containsKey("w")) {
										user.put("w", userdata.get((int)_repeat74).get("w").toString());
									}
									else {
										user.put("w", "0");
									}
								}
							}
							progressbar1.setVisibility(View.VISIBLE);
							fb_db.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(user);
						}
						@Override
						public void onCancelled(DatabaseError _databaseError) {
						}
					});
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Login Not successful");
				}
			}
		});
	}
	//[END auth_with_google]
	{
	}
	
	
	public void _bottomsheet_privicy() {
		bottomsheet = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
		View bottomsheetV;
		bottomsheetV = getLayoutInflater().inflate(R.layout.privacy,null );
		bottomsheet.setContentView(bottomsheetV);
		bottomsheet.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
		final CheckBox checkbox1 = (CheckBox) bottomsheetV.findViewById(R.id.checkbox1);
		final Button button1 = (Button) bottomsheetV.findViewById(R.id.button1);
		final Button button2 = (Button) bottomsheetV.findViewById(R.id.button2);
		final LinearLayout linear1 = (LinearLayout) bottomsheetV.findViewById(R.id.linear1);
		final LinearLayout linear4 = (LinearLayout) bottomsheetV.findViewById(R.id.linear4);
		final TextView textview3 = (TextView) bottomsheetV.findViewById(R.id.textview3);
		final TextView textview5 = (TextView) bottomsheetV.findViewById(R.id.textview5);
		linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0xFFFFFFFF));
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)80, 0xFF000000));
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bottomsheet.dismiss();
				finish();
			}
		});
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (checkbox1.isChecked()) {
					shared.edit().putString("agreed", "true").commit();
					bottomsheet.dismiss();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Please agree first");
				}
			}
		});
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				privicypolicy.setAction(Intent.ACTION_VIEW);
				privicypolicy.setData(Uri.parse("https://doc-hosting.flycricket.io/mrearn-privacy-policy/dbba0112-a584-448e-bec0-28b5dd9a1c5e/privacy"));
				startActivity(privicypolicy);
			}
		});
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				privicypolicy.setAction(Intent.ACTION_VIEW);
				privicypolicy.setData(Uri.parse("https://doc-hosting.flycricket.io/mrearn-terms-of-use/ccdfc5ae-5ae9-432b-9632-56807e2aeaf9/terms"));
				startActivity(privicypolicy);
			}
		});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}