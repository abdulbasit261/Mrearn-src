package com.teamabhpk.mrearn;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.ads.mediation.unity.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.unity3d.ads.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.jetbrains.kotlin.*;
import org.json.*;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;
import com.unity3d.ads.UnityAds;

public class FragHomeFragmentActivity extends Fragment {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String string = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String id = "";
	private String surah = "";
	private String verse = "";
	private HashMap<String, Object> addetails = new HashMap<>();
	private HashMap<String, Object> listdata = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> verses = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> quranmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map3 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listd = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview3;
	private ListView listview1;
	private Button button1;
	private CircleImageView circleimageview1;
	private LinearLayout linear3;
	private MaterialButton materialbutton1;
	private LinearLayout linear4;
	private TextView textview2;
	private TextView textview1;
	private ImageView imageview1;
	
	private FirebaseAuth fb_auth;
	private OnCompleteListener<AuthResult> _fb_auth_create_user_listener;
	private OnCompleteListener<AuthResult> _fb_auth_sign_in_listener;
	private OnCompleteListener<Void> _fb_auth_reset_password_listener;
	private OnCompleteListener<Void> fb_auth_updateEmailListener;
	private OnCompleteListener<Void> fb_auth_updatePasswordListener;
	private OnCompleteListener<Void> fb_auth_emailVerificationSentListener;
	private OnCompleteListener<Void> fb_auth_deleteUserListener;
	private OnCompleteListener<Void> fb_auth_updateProfileListener;
	private OnCompleteListener<AuthResult> fb_auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fb_auth_googleSignInListener;
	
	private SharedPreferences app;
	private MediaPlayer mediaplayer;
	private Intent i = new Intent();
	private DatabaseReference fb_db = _firebase.getReference("users");
	private ChildEventListener _fb_db_child_listener;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.frag_home_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		linear2 = _view.findViewById(R.id.linear2);
		textview3 = _view.findViewById(R.id.textview3);
		listview1 = _view.findViewById(R.id.listview1);
		button1 = _view.findViewById(R.id.button1);
		circleimageview1 = _view.findViewById(R.id.circleimageview1);
		linear3 = _view.findViewById(R.id.linear3);
		materialbutton1 = _view.findViewById(R.id.materialbutton1);
		linear4 = _view.findViewById(R.id.linear4);
		textview2 = _view.findViewById(R.id.textview2);
		textview1 = _view.findViewById(R.id.textview1);
		imageview1 = _view.findViewById(R.id.imageview1);
		fb_auth = FirebaseAuth.getInstance();
		app = getContext().getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				UnityAds.load("bushii", loadListener);
			}
		});
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FirebaseAuth.getInstance().signOut();
			}
		});
		
		_fb_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("w")) {
						textview3.setText("$".concat(_childValue.get("w").toString()));
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fb_db.addChildEventListener(_fb_db_child_listener);
		
		fb_auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		try{
			button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)3, 0xFF4CAF50, Color.TRANSPARENT));
			textview1.setText(FirebaseAuth.getInstance().getCurrentUser().getDisplayName());
			textview2.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
			Glide.with(getContext().getApplicationContext()).load(Uri.parse(FirebaseAuth.getInstance().getCurrentUser().getPhotoUrl().toString())).into(circleimageview1);
			if (app.contains("verses")) {
				verses = new Gson().fromJson(app.getString("verses", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}
			else {
				{
					try{
							java.io.InputStream stringIn = getActivity().getAssets().open("quran_ur.json");
							           int stringSi = stringIn.available();
							           byte[] stringBu = new byte[stringSi];
							           stringIn.read(stringBu);
							           stringIn.close();
							           string = new String(stringBu, "UTF-8");
					}catch(Exception e){
							 
					}
				}
				map3 = new Gson().fromJson(string, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				for(int _repeat27 = 0; _repeat27 < (int)(map3.size()); _repeat27++) {
					quranmap = new Gson().fromJson(new Gson().toJson((ArrayList<HashMap<String,Object>>)map3.get((int)(_repeat27)).get("verses")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					id = map3.get((int)_repeat27).get("id").toString();
					for(int _repeat37 = 0; _repeat37 < (int)(quranmap.size()); _repeat37++) {
						map = new HashMap<>();
						map.put("s", id);
						map.put("text", quranmap.get((int)_repeat37).get("text").toString());
						map.put("v", quranmap.get((int)_repeat37).get("id").toString());
						verses.add(map);
					}
				}
				app.edit().putString("verses", new Gson().toJson(verses)).commit();
			}
			listview1.setHorizontalScrollBarEnabled(false);
			listview1.setVerticalScrollBarEnabled(false);
			listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
			listview1.setAdapter(new Listview1Adapter(verses));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			fb_db.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					listd = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							listd.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					for(int _repeat103 = 0; _repeat103 < (int)(listd.size()); _repeat103++) {
						if (listd.get((int)_repeat103).containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (listd.get((int)_repeat103).containsKey("w")) {
								textview3.setText("$".concat(listd.get((int)_repeat103).get("w").toString()));
							}
						}
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}catch(Exception e){
			((ClipboardManager) getContext().getSystemService(getContext().getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", e.toString()));
		}
	}
	
	public void _UnityAds(final String _UnityGameID, final boolean _enableRealAds) {
		UnityAds.initialize(((AppCompatActivity) getActivity()), _UnityGameID, !_enableRealAds, new IUnityAdsInitializationListener() {
						@Override
						public void onInitializationComplete() {
										
						 		
								
								 }
					
					    @Override
					    public void onInitializationFailed(UnityAds.UnityAdsInitializationError IUnityAdErrorPlayBack, String errorMessage) {
							 		
					}
		});
	}
	private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
			
			@Override
			public void onUnityAdsAdLoaded(String __UnityPlacementID) {
					UnityAds.show(((AppCompatActivity) getActivity()), __UnityPlacementID, new UnityAdsShowOptions(), showListener);
		}
			@Override
			public void onUnityAdsFailedToLoad(String __UnityPlacementID, UnityAds.UnityAdsLoadError IUnityAdErrorPlayBack, String message) {
			SketchwareUtil.showMessage(getContext().getApplicationContext(), __UnityPlacementID.concat(":".concat(IUnityAdErrorPlayBack.toString())));
			}
		
		};
	
	private BannerView.IListener bannerListener = new BannerView.IListener() {
				
					@Override
				public void onBannerLoaded(BannerView bannerAdView) {
							 
				}
				
				@Override
				public void onBannerFailedToLoad(BannerView bannerAdView, BannerErrorInfo IUnityAdErrorPlayBack) {
							SketchwareUtil.showMessage(getContext().getApplicationContext(), IUnityAdErrorPlayBack.toString());
				}
				
				@Override
				public void onBannerShown(BannerView bannerAdView) {
							SketchwareUtil.showMessage(getContext().getApplicationContext(), "Banner Shown");
				}
				@Override
				public void onBannerClick(BannerView bannerAdView) {
							 
				}
				@Override
				public void onBannerLeftApplication(BannerView bannerAdView) {
							 
				}
				
	};
	private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
			 @Override
			public void onUnityAdsShowFailure(String __UnityPlacementID, UnityAds.UnityAdsShowError IUnityAdErrorPlayBack, String message) {
					  SketchwareUtil.showMessage(getContext().getApplicationContext(), __UnityPlacementID.concat(":".concat(IUnityAdErrorPlayBack.toString())));
			}
			
		
			@Override
			public void onUnityAdsShowStart(String __UnityPlacementID) {
					
					if (__UnityPlacementID.equals("bushii")) {
				SketchwareUtil.showMessage(getContext().getApplicationContext(), "UnityRewardAd Showing");
			}
			else {
				SketchwareUtil.showMessage(getContext().getApplicationContext(), "UnityInterstitialAd Showing");
			}
			}
			
		
			@Override
			public void onUnityAdsShowClick(String __UnityPlacementID) {
					
					 
			}
			
		
			@Override
			public void onUnityAdsShowComplete(String __UnityPlacementID, UnityAds.UnityAdsShowCompletionState __UnityAdsState) {
			 if (__UnityPlacementID.equals("bushii")) {
				if (__UnityAdsState.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
					SketchwareUtil.showMessage(getContext().getApplicationContext(), "onAdRewardedComplete");
				}
			}
			else {
				SketchwareUtil.showMessage(getContext().getApplicationContext(), "onAdInterstitialComplete");
			}
			addetails = new HashMap<>();
			addetails.put("user", "");
			addetails.put("", "");
					
		}
		
	};
	
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.quran, null);
			}
			
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ProgressBar progressbar1 = _view.findViewById(R.id.progressbar1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			try{
				linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)1, 0xFF4CAF50, 0xFFFFFFFF));
				imageview1.setColorFilter(0xFF4CAF50, PorterDuff.Mode.MULTIPLY);
				progressbar1.setVisibility(View.GONE);
				textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/arabic.ttf"), 1);
				textview1.setText(_data.get((int)_position).get("text").toString());
				imageview1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						progressbar1.setVisibility(View.VISIBLE);
						surah = _data.get((int)_position).get("s").toString().replace(".0", "");
						verse = _data.get((int)_position).get("v").toString().replace(".0", "");
						if (surah.length() == 1) {
							surah = "00".concat(surah);
						}
						else {
							if (surah.length() == 2) {
								surah = "0".concat(surah);
							}
							else {
								surah = surah;
							}
						}
						if (verse.length() == 1) {
							verse = "00".concat(verse);
						}
						else {
							if (verse.length() == 2) {
								verse = "0".concat(verse);
							}
							else {
								verse = verse;
							}
						}
						mediaplayer = MediaPlayer.create(getContext().getApplicationContext(), Uri.parse("https://everyayah.com/data/Saood_ash-Shuraym_128kbps/".concat(surah.concat(verse).concat(".mp3"))));
						mediaplayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
							    @Override
							    public void onPrepared(MediaPlayer mp) {
								        
								    }
						});
						
						
						mediaplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
							    @Override
							    public void onCompletion(MediaPlayer mp) {
								        progressbar1.setVisibility(View.GONE);
								verses.remove((int)(_position));
											app.edit().putString("verses", new Gson().toJson(verses)).commit();
								UnityAds.load("bushii", loadListener);
								SketchwareUtil.showMessage(getContext().getApplicationContext(), "Ad is loading !!!");
								    }
						});
						
						mediaplayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
							    @Override
							    public void onBufferingUpdate(MediaPlayer mp, int percent) {
								       progressbar1.setIndeterminate(false); progressbar1.setProgress((int)mediaplayer.getCurrentPosition());
											progressbar1.setMax((int)mediaplayer.getDuration());
								    }
						});
						
						mediaplayer.setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener() {
							    @Override
							    public void onSeekComplete(MediaPlayer mp) {
								        
								    }
						});
						
						mediaplayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
							    @Override
							    public boolean onError(MediaPlayer mp, int what, int extra) {
								        Log.d("MediaPlayer", "onError: " + what + ", " + extra);
								        return true;
								    }
						});
						
						mediaplayer.setOnInfoListener(new MediaPlayer.OnInfoListener() {
							    @Override
							    public boolean onInfo(MediaPlayer mp, int what, int extra) {
								        Log.d("MediaPlayer", "onInfo: " + what + ", " + extra);
								        return true;
								    }
						});
						mediaplayer.start();
					}
				});
			}catch(Exception e){
				((ClipboardManager) getContext().getSystemService(getContext().getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", e.toString()));
			}
			
			return _view;
		}
	}
}