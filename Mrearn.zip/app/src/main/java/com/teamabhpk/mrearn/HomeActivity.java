package com.teamabhpk.mrearn;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ProgressBar;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.google.ads.mediation.unity.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.unity3d.ads.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.jetbrains.kotlin.*;
import org.json.*;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;
import com.unity3d.ads.UnityAds;

public class HomeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String string = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String surah = "";
	private String verse = "";
	private double intt = 0;
	private String id = "";
	private HashMap<String, Object> addetails = new HashMap<>();
	private double version = 0;
	private double w = 0;
	private double e = 0;
	
	private ArrayList<HashMap<String, Object>> quranmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> verses = new ArrayList<>();
	private ArrayList<String> surahids = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listdata = new ArrayList<>();
	
	private ProgressBar progressbar1;
	private ViewPager viewpager1;
	private BottomNavigationView bottomnavigation1;
	
	private FirebaseAuth fb_auth;
	private OnCompleteListener<AuthResult> _fb_auth_create_user_listener;
	private OnCompleteListener<AuthResult> _fb_auth_sign_in_listener;
	private OnCompleteListener<Void> _fb_auth_reset_password_listener;
	private OnCompleteListener<Void> fb_auth_updateEmailListener;
	private OnCompleteListener<Void> fb_auth_updatePasswordListener;
	private OnCompleteListener<Void> fb_auth_emailVerificationSentListener;
	private OnCompleteListener<Void> fb_auth_deleteUserListener;
	private OnCompleteListener<Void> fb_auth_updateProfileListener;
	private OnCompleteListener<AuthResult> fb_auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fb_auth_googleSignInListener;
	
	private SharedPreferences app;
	private MediaPlayer mediaplayer;
	private Intent intent = new Intent();
	private DatabaseReference fb_db = _firebase.getReference("users");
	private ChildEventListener _fb_db_child_listener;
	private Frag_adapFragmentAdapter frag_adap;
	private Calendar c = Calendar.getInstance();
	private SharedPreferences shared;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		progressbar1 = findViewById(R.id.progressbar1);
		viewpager1 = findViewById(R.id.viewpager1);
		bottomnavigation1 = findViewById(R.id.bottomnavigation1);
		fb_auth = FirebaseAuth.getInstance();
		app = getSharedPreferences("data", Activity.MODE_PRIVATE);
		frag_adap = new Frag_adapFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		shared = getSharedPreferences("app", Activity.MODE_PRIVATE);
		
		viewpager1.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrolled(int _position, float _positionOffset, int _positionOffsetPixels) {
				
			}
			
			@Override
			public void onPageSelected(int _position) {
				bottomnavigation1.getMenu().findItem(_position).setChecked(true);
			}
			
			@Override
			public void onPageScrollStateChanged(int _scrollState) {
				
			}
		});
		
		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(MenuItem item) {
				final int _itemId = item.getItemId();
				viewpager1.setCurrentItem((int)_itemId);
				return true;
			}
		});
		
		_fb_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("update")) {
					if (_childValue.containsKey("version")) {
						if (Double.parseDouble(_childValue.get("version").toString()) > version) {
							intent.setClass(getApplicationContext(), UpdateActivity.class);
							startActivity(intent);
						}
					}
				}
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("w")) {
						w = Double.parseDouble(_childValue.get("w").toString());
					}
					else {
						w = 0;
					}
					if (_childValue.containsKey("e")) {
						e = Double.parseDouble(_childValue.get("e").toString());
					}
					else {
						e = 0;
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fb_db.addChildEventListener(_fb_db_child_listener);
		
		fb_auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fb_auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fb_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		try{
			progressbar1.setVisibility(View.VISIBLE);
			version = 100;
			frag_adap.setTabCount(5);
			viewpager1.setAdapter(frag_adap);
			bottomnavigation1.getMenu().add(0, 0, 0, "Home").setIcon(R.drawable.ic_home_black);
			bottomnavigation1.getMenu().add(0, 1, 0, "Withdraw").setIcon(R.drawable.ic_account_balance_wallet_black);
			bottomnavigation1.getMenu().add(0, 2, 0, "Analysis").setIcon(R.drawable.ic_equalizer_black);
			bottomnavigation1.getMenu().add(0, 3, 0, "Account").setIcon(R.drawable.ic_timer_auto_black);
			bottomnavigation1.getMenu().add(0, 4, 0, "Chat").setIcon(R.drawable.ic_mode_comment_black);
			bottomnavigation1.setItemRippleColor(ColorStateList.valueOf(0xFFFFFFFF));
			bottomnavigation1.setItemIconTintList(ColorStateList.valueOf(0xFF4CAF50));
			bottomnavigation1.setItemTextColor(ColorStateList.valueOf(0xFF4CAF50));
			_UnityAds("5637966", true);
			fb_db.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					listdata = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							listdata.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					progressbar1.setVisibility(View.INVISIBLE);
					for(int _repeat201 = 0; _repeat201 < (int)(listdata.size()); _repeat201++) {
						if (listdata.get((int)_repeat201).containsKey("e")) {
							e = Double.parseDouble(listdata.get((int)_repeat201).get("e").toString());
						}
						else {
							e = 0.0001d;
						}
						if (listdata.get((int)_repeat201).containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (listdata.get((int)_repeat201).containsKey("w")) {
								w = Double.parseDouble(listdata.get((int)_repeat201).get("w").toString());
							}
							else {
								w = 0.0000d;
							}
							if (listdata.get((int)_repeat201).containsKey("update")) {
								if (listdata.get((int)_repeat201).containsKey("version")) {
									if (Double.parseDouble(listdata.get((int)_repeat201).get("version").toString()) > version) {
										intent.setClass(getApplicationContext(), UpdateActivity.class);
										startActivity(intent);
									}
								}
							}
						}
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}catch(Exception e){
			((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", e.toString()));
		}
	}
	
	public class Frag_adapFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public Frag_adapFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new FragHomeFragmentActivity();
			}
			if (_position == 1) {
				return new FragWithdraaFragmentActivity();
			}
			if (_position == 2) {
				return new FragAnalysisFragmentActivity();
			}
			if (_position == 3) {
				return new FragAccountFragmentActivity();
			}
			if (_position == 4) {
				return new ChatFragmentActivity();
			}
			return null;
		}
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		
		
	}
	public void _UnityAds(final String _UnityGameID, final boolean _enableRealAds) {
		UnityAds.initialize(this, _UnityGameID, !_enableRealAds, new IUnityAdsInitializationListener() {
					@Override
					public void onInitializationComplete() {
								
				 		
						
						 }
				
				    @Override
				    public void onInitializationFailed(UnityAds.UnityAdsInitializationError IUnityAdErrorPlayBack, String errorMessage) {
					 		
				}
		});
	}
	private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
			
			@Override
			public void onUnityAdsAdLoaded(String __UnityPlacementID) {
					UnityAds.show(HomeActivity.this, __UnityPlacementID, new UnityAdsShowOptions(), showListener);
			
		}
			@Override
			public void onUnityAdsFailedToLoad(String __UnityPlacementID, UnityAds.UnityAdsLoadError IUnityAdErrorPlayBack, String message) {
			SketchwareUtil.showMessage(getApplicationContext(), __UnityPlacementID.concat(":".concat(IUnityAdErrorPlayBack.toString())));
			}
		
		};
	
	private BannerView.IListener bannerListener = new BannerView.IListener() {
				
					@Override
				public void onBannerLoaded(BannerView bannerAdView) {
							 
				}
				
				@Override
				public void onBannerFailedToLoad(BannerView bannerAdView, BannerErrorInfo IUnityAdErrorPlayBack) {
							SketchwareUtil.showMessage(getApplicationContext(), IUnityAdErrorPlayBack.toString());
				}
				
				@Override
				public void onBannerShown(BannerView bannerAdView) {
							SketchwareUtil.showMessage(getApplicationContext(), "Banner Shown");
				}
				@Override
				public void onBannerClick(BannerView bannerAdView) {
							 
				}
				@Override
				public void onBannerLeftApplication(BannerView bannerAdView) {
							 
				}
				
	};
	private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
			 @Override
			public void onUnityAdsShowFailure(String __UnityPlacementID, UnityAds.UnityAdsShowError IUnityAdErrorPlayBack, String message) {
					  SketchwareUtil.showMessage(getApplicationContext(), __UnityPlacementID.concat(":".concat(IUnityAdErrorPlayBack.toString())));
			}
			
		
			@Override
			public void onUnityAdsShowStart(String __UnityPlacementID) {
					
					if (__UnityPlacementID.equals("bushii")) {
				SketchwareUtil.showMessage(getApplicationContext(), "UnityRewardAd Showing");
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "UnityInterstitialAd Showing");
			}
			}
			
		
			@Override
			public void onUnityAdsShowClick(String __UnityPlacementID) {
					
					 
			}
			
		
			@Override
			public void onUnityAdsShowComplete(String __UnityPlacementID, UnityAds.UnityAdsShowCompletionState __UnityAdsState) {
			 if (__UnityPlacementID.equals("bushii")) {
				if (__UnityAdsState.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
					SketchwareUtil.showMessage(getApplicationContext(), "onAdRewardedComplete");
				}
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "onAdInterstitialComplete");
			}
			addetails = new HashMap<>();
			addetails.put("userid", FirebaseAuth.getInstance().getCurrentUser().getUid());
			addetails.put("useremail", FirebaseAuth.getInstance().getCurrentUser().getEmail());
			if (!(e == 0)) {
				addetails.put("w", String.valueOf(w + e));
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "Currently reward rate failed !");
			}
			addetails.put("ad,watched,at,".concat(new SimpleDateFormat("mm:hh::ss:a:MM:aa").format(c.getTime())).concat("<".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()).concat(">")), new SimpleDateFormat("yyyy:MM:dd:mm:hh::ss:aa").format(c.getTime()));
			fb_db.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(addetails);		
		}
		
	};
	
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}